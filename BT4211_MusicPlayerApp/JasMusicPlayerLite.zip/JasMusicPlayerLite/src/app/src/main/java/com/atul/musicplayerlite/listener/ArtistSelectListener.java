package com.atul.musicplayerlite.listener;

import com.atul.musicplayerlite.model.Artist;

public interface ArtistSelectListener {
    void selectedArtist(Artist artist);
}
