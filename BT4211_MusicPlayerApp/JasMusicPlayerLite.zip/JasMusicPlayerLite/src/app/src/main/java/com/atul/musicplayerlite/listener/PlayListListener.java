package com.atul.musicplayerlite.listener;

import android.content.Context;

import com.atul.musicplayerlite.model.Music;

public interface PlayListListener {
    void option(Context context, Music music);
}
