package com.atul.musicplayerlite.listener;

import com.atul.musicplayerlite.model.Album;

public interface AlbumSelectListener {
    void selectedAlbum(Album album);
}
